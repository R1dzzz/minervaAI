# MinervaAI v2.0 — Setup & Deployment Guide
**By RLC™ (RoogLiteCore), Pandansari**

---

## Project Structure

```
minervaAI/
│
├── index.html          ← Main chat app (auth-protected)
├── login.html          ← Login page
├── register.html       ← Registration page
│
├── css/
│   └── styles.css      ← All styles (light + dark mode)
│
├── js/
│   ├── auth.js         ← Supabase auth logic
│   ├── chat.js         ← Chat + session management
│   ├── api.js          ← Gemini proxy API caller
│   └── ui.js           ← UI helpers (theme, toasts, sidebar)
│
├── assets/
│   └── images/         ← Logo files
│       ├── logo-f.png
│       ├── logo-h.png
│       └── logo-intro.png
│
└── supabase/
    └── functions/
        └── gemini-proxy/
            └── index.ts  ← Edge Function (secure Gemini proxy)
```

---

## STEP 1 — Create Supabase Project

1. Go to [https://supabase.com](https://supabase.com)
2. Click **New Project**
3. Choose a name: `minervaai`
4. Set a strong database password
5. Choose region closest to your users
6. Click **Create new project** — wait ~2 min

---

## STEP 2 — Create the `profiles` Table

In your Supabase dashboard → **SQL Editor** → run this:

```sql
-- Create profiles table
CREATE TABLE public.profiles (
  id         UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policy: Users can only read/write their own profile
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);
```

---

## STEP 3 — Get Supabase Credentials

In your Supabase dashboard → **Settings** → **API**:

- **Project URL**: copy `https://xxxx.supabase.co`
- **anon public key**: copy the long `anon` key

Open `js/auth.js` and replace:
```javascript
const SUPABASE_URL      = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
```

---

## STEP 4 — Get Gemini API Key

1. Go to [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. Click **Create API Key**
3. Copy the key — you will add it to Supabase secrets (NOT the frontend)

---

## STEP 5 — Install Supabase CLI

```bash
npm install -g supabase
```

Or on macOS:
```bash
brew install supabase/tap/supabase
```

---

## STEP 6 — Login & Link Project

```bash
supabase login
supabase init
supabase link --project-ref YOUR_PROJECT_REF
```

`YOUR_PROJECT_REF` is the string in your Supabase URL:
`https://[PROJECT_REF].supabase.co`

---

## STEP 7 — Set Gemini API Key as Secret

```bash
supabase secrets set GEMINI_API_KEY=your_gemini_api_key_here
```

To verify:
```bash
supabase secrets list
```

---

## STEP 8 — Deploy the Edge Function

```bash
supabase functions deploy gemini-proxy
```

After deploy, your function URL will be:
```
https://YOUR_PROJECT_REF.supabase.co/functions/v1/gemini-proxy
```

---

## STEP 9 — Update api.js with Function URL

Open `js/api.js` and replace:
```javascript
const GEMINI_PROXY_URL = 'YOUR_SUPABASE_URL/functions/v1/gemini-proxy';
```

With your actual URL:
```javascript
const GEMINI_PROXY_URL = 'https://xxxx.supabase.co/functions/v1/gemini-proxy';
```

---

## STEP 10 — Enable Email Auth in Supabase

1. In Supabase dashboard → **Authentication** → **Providers**
2. Make sure **Email** is enabled
3. Optional: Disable **Confirm email** during testing
   - Go to **Authentication** → **Settings**
   - Toggle off "Enable email confirmations"

---

## STEP 11 — Run Locally

Since this is plain HTML/CSS/JS, you can use any local server:

```bash
# Option 1: VS Code Live Server extension (recommended)
# Right-click index.html → "Open with Live Server"

# Option 2: Python
python -m http.server 3000

# Option 3: npx
npx serve .
```

Open: `http://localhost:3000`

---

## STEP 12 — Deploy to Production (optional)

**Netlify (recommended — free):**
1. Drag & drop your project folder to [netlify.com/drop](https://app.netlify.com/drop)
2. Done! You get a live URL instantly.

**Vercel:**
```bash
npx vercel
```

**GitHub Pages:**
1. Push your project to GitHub
2. Go to Settings → Pages → Deploy from main branch

---

## Supabase Auth Flow

```
Register page
  → signUp(email, password, name)
  → Supabase creates auth.users row
  → Insert into public.profiles {id, name, email}
  → Redirect to index.html

Login page
  → signIn(email, password)
  → Get session token
  → Redirect to index.html

index.html
  → requireAuth() checks session
  → If no session → redirect to login.html
  → If session → load profile, show chat
```

---

## Gemini Proxy Flow

```
User types message in index.html
  ↓
chat.js: sendMessage()
  ↓
api.js: callGeminiProxy(conversationHistory)
  ↓  [Sends with Authorization: Bearer <session_token>]
Supabase Edge Function: gemini-proxy/index.ts
  ↓  [Verifies token with supabase.auth.getUser()]
  ↓  [Reads GEMINI_API_KEY from Deno.env]
  ↓  [Calls Gemini API server-side]
Gemini API → response text
  ↓
Edge Function returns { text }
  ↓
chat.js displays AI response
```

**The Gemini API key NEVER touches the browser.**

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Not authenticated" error | Make sure login works; check SUPABASE_URL & ANON_KEY |
| Function returns 502 | Check GEMINI_API_KEY secret is set; check function logs |
| Profile not loading | Run the SQL in Step 2; check RLS policies |
| Chat doesn't work | Check browser console; verify GEMINI_PROXY_URL in api.js |
| CORS error | Re-deploy edge function; check corsHeaders in index.ts |

Check function logs:
```bash
supabase functions logs gemini-proxy
```

---

## Credits

MinervaAI v2.0  
Built by **RLC™** (RoogLiteCore), Pandansari  
Powered by **Google Gemini AI** & **Supabase**  
Copyright © 2025. All Rights Reserved.
